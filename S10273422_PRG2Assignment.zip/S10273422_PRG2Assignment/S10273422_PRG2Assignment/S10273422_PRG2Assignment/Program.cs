﻿using S10273422_PRG2Assignment;

Restaurant[] restaurants = new Restaurant[50];
int restaurantCount = 0;

Customer[] customers = new Customer[100];
int customerCount = 0;


LoadRestaurants();
LoadFoodItems();
LoadSpecialOffers();
LoadCustomers();
LoadOrders();

while (true)
{
    Console.WriteLine("\n=== GRUBEROO SYSTEM ===");
    Console.WriteLine("1. Display Restaurants & Menus (Feature 3)");
    Console.WriteLine("2. Create New Order (Feature 5)");
    Console.WriteLine("3. Modify Order (Feature 7)");
    Console.WriteLine("0. Exit");
    Console.Write("Choose: ");

    string choice = Console.ReadLine();

    if (choice == "0")
    {
        break;
    }

    if (choice == "1")
    {
        Feature3_Display();
    }
    else if (choice == "2")
    {
        Feature5_Create();
    }
    else if (choice == "3")
    {
        Feature7_Modify();
    }
    else
    {
        Console.WriteLine("Invalid option.");
    }
}

// feature 1
void LoadRestaurants()
{
    string[] lines = File.ReadAllLines("restaurants.csv");

    for (int i = 1; i < lines.Length; i++)
    {
        if (string.IsNullOrWhiteSpace(lines[i]))
        {
            continue;
        }

        string[] p = lines[i].Split(',');

        restaurants[restaurantCount++] = new Restaurant(p[0], p[1], p[2]);
    }
}

void LoadFoodItems()
{
    for (int i = 0; i < restaurantCount; i++)
    {
        restaurants[i].AddMenu(new Menu("M001", "Main Menu"));
    }

    string[] lines = File.ReadAllLines("fooditems.csv");

    for (int i = 1; i < lines.Length; i++)
    {
        if (string.IsNullOrWhiteSpace(lines[i]))
        {
            continue;
        }

        string[] p = lines[i].Split(',');

        Restaurant r = FindRestaurant(p[0]);

        if (r == null)
        {
            continue;
        }

        Menu m = r.GetMenus()[0];

        m.AddFoodItem(new FoodItem(p[1], p[2], double.Parse(p[3]), ""));
    }
}
//feature 2
void LoadCustomers()
{
    string[] lines = File.ReadAllLines("customers.csv");

    for (int i = 1; i < lines.Length; i++)
    {
        if (string.IsNullOrWhiteSpace(lines[i]))
        {
            continue;
        }

        string[] p = lines[i].Split('\t');

        customers[customerCount++] = new Customer(p[1], p[0]);
    }
}

void LoadSpecialOffers()
{
    string[] lines = File.ReadAllLines("specialoffers.csv");

    for (int i = 1; i < lines.Length; i++)
    {
        if (string.IsNullOrWhiteSpace(lines[i]))
        {
            continue;
        }

        string[] p = lines[i].Split(',');

        double d = 0;

        if (p[3] != "-")
        {
            d = double.Parse(p[3]) / 100;
        }

        Restaurant r = FindRestaurantByName(p[0]);

        if (r == null)
        {
            continue;
        }

        r.AddSpecialOffer(new SpecialOffer(p[1], p[2], d));
    }
}

void LoadOrders()
{
    string[] lines = File.ReadAllLines("orders.csv");

    for (int i = 1; i < lines.Length; i++)
    {
        if (string.IsNullOrWhiteSpace(lines[i]))
        {
            continue;
        }

        string line = lines[i];

        int q = line.IndexOf('"');

        string items = "";

        if (q != -1)
        {
            items = line.Substring(q + 1);
            items = items.Substring(0, items.Length - 1);
            line = line.Substring(0, q - 1);
        }

        string[] p = line.Split(',');

        int id = int.Parse(p[0]);
        string email = p[1];
        string rid = p[2];

        DateTime created = DateTime.Parse(p[6]);
        string status = p[8];

        Customer c = FindCustomer(email);
        Restaurant r = FindRestaurant(rid);

        if (c == null || r == null) continue;

        Order o = new Order(id, created, status, DateTime.Now, p[5], "CC");

        if (items != "")
        {
            string[] list = items.Split('|');

            foreach (string it in list)
            {
                string[] x = it.Split(',');

                string name = x[0].Trim();
                int qty = int.Parse(x[1]);

                double price = FindPrice(r, name);

                o.AddOrderedFoodItem(
                    new OrderedFoodItem(name, price, qty)
                );
            }
        }

        c.AddOrder(o);
        r.AddOrder(o);
    }
}

// feature 3
void Feature3_Display()
{
    for (int i = 0; i < restaurantCount; i++)
    {
        Restaurant r = restaurants[i];

        Console.WriteLine($"\n{r.RestaurantName}");

        FoodItem[] items = r.GetAllFoodItems();

        for (int j = 0; j < items.Length; j++)
            Console.WriteLine($"  {items[j].ItemName} - ${items[j].ItemPrice}");
    }
}

// feature 5
void Feature5_Create()
{
    Console.Write("Customer Email: ");
    Customer c = FindCustomer(Console.ReadLine());

    if (c == null)
    {
        Console.WriteLine("Customer not found.");
        return;
    }

    Console.Write("Restaurant ID: ");
    Restaurant r = FindRestaurant(Console.ReadLine());

    if (r == null)
    {
        Console.WriteLine("Restaurant not found.");
        return;
    }

    Order o = new Order(GenerateId(), DateTime.Now, "Pending", DateTime.Now.AddHours(1), "Unknown", "CC");

    FoodItem[] items = r.GetAllFoodItems();

    while (true)
    {
        for (int i = 0; i < items.Length; i++)
        {
            Console.WriteLine($"{i + 1}. {items[i].ItemName}");
        }

        Console.Write("Choose (0 stop): ");
        int ch = int.Parse(Console.ReadLine());

        if (ch == 0)
        {
            break;
        }

        Console.Write("Quantity: ");
        int qty = int.Parse(Console.ReadLine());

        o.AddOrderedFoodItem(new OrderedFoodItem(items[ch - 1].ItemName, items[ch - 1].ItemPrice, qty));
    }

    Console.Write("Pay now? (Y/N): ");
    if (Console.ReadLine().ToUpper() != "Y")
    {
        return;
    }

    o.OrderPaid = true;

    c.AddOrder(o);
    r.AddOrder(o);

    Console.WriteLine("Order Created. ID: " + o.OrderId);
}

// feature 7
void Feature7_Modify()
{
    Console.Write("Customer Email: ");
    Customer c = FindCustomer(Console.ReadLine());

    if (c == null) return;

    Order[] list = c.GetPendingOrders();

    if (list.Length == 0)
    {
        Console.WriteLine("No pending orders.");
        return;
    }

    foreach (Order o in list)
        Console.WriteLine(o.OrderId);

    Console.Write("Order ID: ");
    int id = int.Parse(Console.ReadLine());

    Order ord = c.GetOrderById(id);

    if (ord == null) return;

    Console.WriteLine("1. Change Address");
    Console.WriteLine("2. Clear Items");
    Console.Write("Choose: ");

    string ch = Console.ReadLine();

    if (ch == "1")
    {
        Console.Write("New Address: ");
        ord.UpdateDeliveryAddress(Console.ReadLine());
    }

    if (ch == "2")
    {
        foreach (var it in ord.GetOrderedFoodItems())
            ord.RemoveOrderedFoodItem(it);
    }

    ord.CalculateOrderTotal();

    Console.WriteLine("Order Updated.");
}



Customer FindCustomer(string email)
{
    for (int i = 0; i < customerCount; i++)
        if (customers[i].EmailAddress == email)
            return customers[i];

    return null;
}

Restaurant FindRestaurant(string id)
{
    for (int i = 0; i < restaurantCount; i++)
        if (restaurants[i].RestaurantId == id)
            return restaurants[i];

    return null;
}

Restaurant FindRestaurantByName(string name)
{
    for (int i = 0; i < restaurantCount; i++)
        if (restaurants[i].RestaurantName == name)
            return restaurants[i];

    return null;
}

double FindPrice(Restaurant r, string name)
{
    FoodItem[] items = r.GetAllFoodItems();

    for (int i = 0; i < items.Length; i++)
        if (items[i].ItemName == name)
            return items[i].ItemPrice;

    return 0;
}

int GenerateId()
{
    int max = 1000;

    for (int i = 0; i < customerCount; i++)
    {
        Order[] os = customers[i].GetOrders();

        for (int j = 0; j < os.Length; j++)
            if (os[j].OrderId > max)
                max = os[j].OrderId;
    }

    return max + 1;
}

