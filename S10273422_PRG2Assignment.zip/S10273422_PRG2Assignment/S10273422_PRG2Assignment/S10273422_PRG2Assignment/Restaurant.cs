﻿using S10273422_PRG2Assignment;

public class Restaurant
{
    public string RestaurantId { get; set; }
    public string RestaurantName { get; set; }
    public string RestaurantEmail { get; set; }
    private Menu[] menus;
    private Order[] orders;
    private SpecialOffer[] specialOffers;
    private int menuCount;
    private int orderCount;
    private int offerCount;

    public Restaurant(string restaurantId, string restaurantName, string restaurantEmail)
    {
        RestaurantId = restaurantId;
        RestaurantName = restaurantName;
        RestaurantEmail = restaurantEmail;
        menus = new Menu[50];
        orders = new Order[500];
        specialOffers = new SpecialOffer[50];
        menuCount = 0;
        orderCount = 0;
        offerCount = 0;
    }

    public void DisplayOrders()
    {
        Console.WriteLine("Orders for " + RestaurantName);
        if (orderCount == 0)
        {
            Console.WriteLine("No orders found.");
            return;
        }
        for (int i = 0; i < orderCount; i++)
        {
            Console.WriteLine(orders[i]);
        }
    }

    public void DisplaySpecialOffers()
    {
        Console.WriteLine("Special Offers for " + RestaurantName);
        if (offerCount == 0)
        {
            Console.WriteLine("No special offers available.");
            return;
        }
        for (int i = 0; i < offerCount; i++)
        {
            Console.WriteLine(specialOffers[i]);
        }
    }

    public void DisplayMenu()
    {
        Console.WriteLine("Menus for " + RestaurantName);
        if (menuCount == 0)
        {
            Console.WriteLine("No menus available.");
            return;
        }
        for (int i = 0; i < menuCount; i++)
        {
            Console.WriteLine(menus[i]);
        }
    }

    public void AddMenu(Menu menu)
    {
        if (menuCount < menus.Length)
        {
            menus[menuCount] = menu;
            menuCount++;
            Console.WriteLine("Menu added successfully!");
        }
        else
        {
            Console.WriteLine("Cannot add more menus!");
        }
    }

    public bool RemoveMenu(Menu menu)
    {
        for (int i = 0; i < menuCount; i++)
        {
            if (menus[i] == menu)
            {
                for (int j = i; j < menuCount - 1; j++)
                {
                    menus[j] = menus[j + 1];
                }
                menus[menuCount - 1] = null;
                menuCount--;
                Console.WriteLine("Menu removed successfully!");
                return true;
            }
        }
        Console.WriteLine("Menu not found!");
        return false;
    }

    public void AddOrder(Order order)
    {
        if (orderCount < orders.Length)
        {
            orders[orderCount] = order;
            orderCount++;
            Console.WriteLine("Order added successfully!");
        }
    }

    public void AddSpecialOffer(SpecialOffer offer)
    {
        if (offerCount < specialOffers.Length)
        {
            specialOffers[offerCount] = offer;
            offerCount++;
            Console.WriteLine("Special offer added successfully!");
        }
    }

    public Menu[] GetMenus()
    {
        Menu[] result = new Menu[menuCount];
        for (int i = 0; i < menuCount; i++)
        {
            result[i] = menus[i];
        }
        return result;
    }

    public override string ToString()
    {
        return $"Restaurant {{ RestaurantId='{RestaurantId}', RestaurantName='{RestaurantName}', RestaurantEmail='{RestaurantEmail}', MenuCount={menuCount} }}";
    }