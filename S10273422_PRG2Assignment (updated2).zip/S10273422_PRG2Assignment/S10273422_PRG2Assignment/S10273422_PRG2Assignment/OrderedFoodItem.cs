﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class OrderedFoodItem
{
    public int QtyOrdered { get; set; }
    public double SubTotal { get; set; }

    public OrderedFoodItem(int qtyOrdered, double subTotal)
    {
        QtyOrdered = qtyOrdered;
        SubTotal = subTotal;
    }

    public double CalculateSubtotal()
    {
        return SubTotal;
    }

    public override string ToString()
    {
        return $"OrderedFoodItem {{ QtyOrdered={QtyOrdered}, SubTotal={SubTotal} }}";
    }
}