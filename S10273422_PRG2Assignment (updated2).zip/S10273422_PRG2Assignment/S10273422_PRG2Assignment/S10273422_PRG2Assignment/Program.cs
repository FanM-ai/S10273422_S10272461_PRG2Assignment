﻿// =====================================================
// Student 1: Fan Ming
// Student 2: Droydon Goh
// =====================================================

using System;

Restaurant[] restaurants = new Restaurant[50];
Customer[] customers = new Customer[50];

int restaurantCount = 0;
int customerCount = 0;

// Feature 1
LoadRestaurants();

void LoadRestaurants()
{
    string[] lines = File.ReadAllLines("restaurants.csv");

    for (int i = 1; i < lines.Length; i++)
    {
        if (string.IsNullOrWhiteSpace(lines[i])) continue;

        string[] p = lines[i].Split(',');

        Restaurant r = new Restaurant(p[0], p[1], p[2]);

        restaurants[restaurantCount] = r;
        restaurantCount++;
    }
}


// Feature 2 - Droydon
LoadAllData();
void LoadAllData()
{
    string[] restLines = File.ReadAllLines("restaurants.csv");

    for (int i = 1; i < restLines.Length; i++)
    {
        if (restLines[i].Length == 0)
        {
            continue;
        }

        string[] p = restLines[i].Split(',');

        Restaurant r = new Restaurant(p[0], p[1], p[2]);

        restaurants[restaurantCount] = r;
        restaurantCount++;
    }

    for (int i = 0; i < restaurantCount; i++)
    {
        Menu m = new Menu("M001", "Main Menu");
        restaurants[i].AddMenu(m);
    }

    string[] foodLines = File.ReadAllLines("fooditems.csv");

    for (int i = 1; i < foodLines.Length; i++)
    {
        if (foodLines[1].Length == 0) 
        { 
            continue; 
        }

        string[] p = foodLines[i].Split(',');

        string restId = p[0];

        for (int j = 0; j < restaurantCount; j++)
        {
            if (restaurants[j].RestaurantId == restId)
            {
                Menu m = restaurants[j].GetMenus()[0];

                FoodItem f = new FoodItem(p[1],p[2],double.Parse(p[3]),"");

                m.AddFoodItem(f);
                break;
            }
        }
    }

    string[] custLines = File.ReadAllLines("customers.csv");

    for (int i = 1; i < custLines.Length; i++)
    {
        string line = custLines[i];

        if (line.Length == 0)
            continue;

        string[] p = custLines[i].Split('\t');

        if (p.Length < 2)
            continue;

        Customer c = new Customer(p[1], p[0]);


        customers[customerCount] = c;
        customerCount++;
    }

    string[] orderLines = File.ReadAllLines("orders.csv");

    for (int i = 1; i < orderLines.Length; i++)
    {
        if (orderLines[i].Length == 0)
        {
            continue;
        }

        string line = orderLines[i];


        string[] mainParts = line.Split('"');


        string left = mainParts[0];
        string items = "";

        if (mainParts.Length > 1)
            items = mainParts[1].Replace("\"", "");

        string[] p = left.Split(',');

        int id = int.Parse(p[0]);
        string email = p[1];
        string restId = p[2];

        DateTime created = DateTime.Parse(p[6]);
        string status = p[8];


        Customer cust = null;

        for (int j = 0; j < customerCount; j++)
        {
            if (customers[j].EmailAddress == email)
                cust = customers[j];
        }


        Restaurant rest = null;

        for (int j = 0; j < restaurantCount; j++)
        {
            if (restaurants[j].RestaurantId == restId)
                rest = restaurants[j];
        }

        if (cust == null || rest == null) 
        { 
            continue;
        }


        Order o = new Order(id,created,status,p[5],"CC");


        if (items != "")
        {
            string[] list = items.Split('|');

            double total = double.Parse(p[7]);
            double perItem = total / list.Length;

            foreach (string it in list)
            {
                string[] x = it.Split(',');

                int qty = int.Parse(x[1]);

                OrderedFoodItem of =
                    new OrderedFoodItem(qty, perItem);

                o.AddOrderedFoodItem(of);
            }
        }

        o.CalculateOrderTotal();

        cust.AddOrder(o);
    }

}

// Feature 3 - Droydon
ViewMenus();

void ViewMenus()
{
    Console.WriteLine("===== Restaurants =====");

    for (int i = 0; i < restaurantCount; i++)
    {
        Console.WriteLine((i + 1) + ". " + restaurants[i].RestaurantName);
    }

    Console.Write("Select restaurant number: ");
    int choice = int.Parse(Console.ReadLine());

    if (choice < 1 || choice > restaurantCount)
    {
        Console.WriteLine("Invalid choice.");
        return;
    }

    Restaurant r = restaurants[choice - 1];

    Console.WriteLine("\nMenu for " + r.RestaurantName);

    Menu[] menus = r.GetMenus();

    if (menus.Length == 0)
    {
        Console.WriteLine("No menu found.");
        return;
    }

    Menu m = menus[0];

    FoodItem[] items = m.GetFoodItems();

    if (items.Length == 0)
    {
        Console.WriteLine("No food items.");
        return;
    }

    for (int i = 0; i < items.Length; i++)
    {
        Console.WriteLine((i + 1) + ". " + items[i]);
    }

    Console.WriteLine("========================");
}

// Feature 5 - Droydon
ViewOrders();
void ViewOrders()
{
    Console.Write("Enter your email: ");
    string email = Console.ReadLine();

    Customer cust = null;

    for (int i = 0; i < customerCount; i++)
    {
        if (customers[i].EmailAddress == email)
        {
            cust = customers[i];
            break;
        }
    }

    if (cust == null)
    {
        Console.WriteLine("Customer not found.");
        return;
    }

    Order[] list = cust.GetOrders();

    if (list.Length == 0)
    {
        Console.WriteLine("No orders found.");
        return;
    }

    Console.WriteLine("\n===== Your Orders =====");

    for (int i = 0; i < list.Length; i++)
    {
        Console.WriteLine((i + 1) + ". " + list[i]);
    }

    Console.WriteLine("=======================");
}

// Feature 7 - Droydon 
ModifyOrder();
void ModifyOrder()
{
    Console.Write("Enter your email: ");
    string email = Console.ReadLine();

    Customer cust = null;

    for (int i = 0; i < customerCount; i++)
    {
        if (customers[i].EmailAddress == email)
        {
            cust = customers[i];
            break;
        }
    }

    if (cust == null)
    {
        Console.WriteLine("Customer not found.");
        return;
    }

    Order[] allOrders = cust.GetOrders();

    Order[] pending = new Order[allOrders.Length];
    int count = 0;

    for (int i = 0; i < allOrders.Length; i++)
    {
        if (allOrders[i].OrderStatus == "Pending" ||
            allOrders[i].OrderStatus == "Preparing")
        {
            pending[count] = allOrders[i];
            count++;
        }
    }

    if (count == 0)
    {
        Console.WriteLine("No pending orders to modify.");
        return;
    }

    Console.WriteLine("\n===== Pending Orders =====");

    for (int i = 0; i < count; i++)
    {
        Console.WriteLine((i + 1) + ". " + pending[i]);
    }

    Console.Write("Select order number: ");
    int choice = int.Parse(Console.ReadLine());

    if (choice < 1 || choice > count)
    {
        Console.WriteLine("Invalid choice.");
        return;
    }

    Order ord = pending[choice - 1];

    Console.WriteLine("\n1. Change Delivery Address");
    Console.WriteLine("2. Change Delivery Date/Time");
    Console.Write("Choose option: ");

    string ch = Console.ReadLine();

    if (ch == "1")
    {
        Console.Write("New Address: ");
        string addr = Console.ReadLine();

        ord.DeliveryAddress = addr;

        Console.WriteLine("Address updated.");
    }
    else if (ch == "2")
    {
        Console.Write("New Date (dd/MM/yyyy): ");
        string d = Console.ReadLine();

        Console.Write("New Time (HH:mm): ");
        string t = Console.ReadLine();

        DateTime dt = DateTime.Parse(d + " " + t);

        ord.DeliveryDateTime = dt;

        Console.WriteLine("Delivery time updated.");
    }
    else
    {
        Console.WriteLine("Invalid option.");
    }
}
