﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;

public class Order
{
    public int OrderId { get; set; }
    public DateTime OrderDateTime { get; set; }
    public double OrderTotal { get; set; }
    public string OrderStatus { get; set; }
    public DateTime DeliveryDateTime { get; set; }
    public string DeliveryAddress { get; set; }
    public string OrderPaymentMethod { get; set; }
    public bool OrderPaid { get; set; }
    public SpecialOffer SpecialOffer { get; set; }
    private OrderedFoodItem[] orderedFoodItems;
    private int itemCount;

    public Order(int orderId, DateTime orderDateTime, string orderStatus,
                 string deliveryAddress, string orderPaymentMethod)
    {
        OrderId = orderId;
        OrderDateTime = orderDateTime;
        OrderStatus = orderStatus;
        DeliveryAddress = deliveryAddress;
        OrderPaymentMethod = orderPaymentMethod;
        OrderTotal = 0.0;
        OrderPaid = false;
        orderedFoodItems = new OrderedFoodItem[100];
        itemCount = 0;
    }

    public double CalculateOrderTotal()
    {
        OrderTotal = 0.0;
        for (int i = 0; i < itemCount; i++)
        {
            OrderTotal += orderedFoodItems[i].SubTotal;
        }
        return OrderTotal;
    }

    public void AddOrderedFoodItem(OrderedFoodItem orderedFoodItem)
    {
        if (itemCount < orderedFoodItems.Length)
        {
            orderedFoodItems[itemCount] = orderedFoodItem;
            itemCount++;
            CalculateOrderTotal();
            Console.WriteLine("Food item added to order!");
        }
        else
        {
            Console.WriteLine("Cannot add more items to order!");
        }
    }

    public bool RemoveOrderedFoodItem(OrderedFoodItem orderedFoodItem)
    {
        for (int i = 0; i < itemCount; i++)
        {
            if (orderedFoodItems[i] == orderedFoodItem)
            {
                for (int j = i; j < itemCount - 1; j++)
                {
                    orderedFoodItems[j] = orderedFoodItems[j + 1];
                }
                orderedFoodItems[itemCount - 1] = null;
                itemCount--;
                CalculateOrderTotal();
                Console.WriteLine("Food item removed from order!");
                return true;
            }
        }
        Console.WriteLine("Food item not found in order!");
        return false;
    }

    public void DisplayOrderedFoodItems()
    {
        Console.WriteLine("Items for Order " + OrderId);
        if (itemCount == 0)
        {
            Console.WriteLine("No items in this order.");
            return;
        }
        for (int i = 0; i < itemCount; i++)
        {
            Console.WriteLine((i + 1) + ". " + orderedFoodItems[i]);
        }
    }

    public OrderedFoodItem[] GetOrderedFoodItems()
    {
        OrderedFoodItem[] result = new OrderedFoodItem[itemCount];
        for (int i = 0; i < itemCount; i++)
        {
            result[i] = orderedFoodItems[i];
        }
        return result;
    }

    public override string ToString()
    {
        return $"Order {{ OrderId={OrderId}, OrderDateTime={OrderDateTime}, OrderTotal={OrderTotal}, OrderStatus='{OrderStatus}', DeliveryAddress='{DeliveryAddress}', OrderPaid={OrderPaid} }}";
    }
}
